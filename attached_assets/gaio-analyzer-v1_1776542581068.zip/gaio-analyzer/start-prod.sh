#!/usr/bin/env bash
# GAIO Analyzer — Produktions-Start
# Baut das Frontend, dann startet nur der FastAPI-Server (serviert alles).

set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"

echo "▶ Frontend bauen ..."
cd "$ROOT/frontend"
npm run build

echo "▶ Starte Produktions-Server auf http://localhost:8000 ..."
cd "$ROOT/backend"
python3 -m uvicorn main:app --host 0.0.0.0 --port "${PORT:-8000}" --workers 2
