#!/usr/bin/env bash
# GAIO Analyzer — Entwicklungsstart
# Startet Backend (Port 8000) und Frontend-Dev-Server (Port 5173) parallel.
# Beenden mit Ctrl+C.

set -e

ROOT="$(cd "$(dirname "$0")" && pwd)"

# ── Prüfungen ──────────────────────────────────────────────────────────────
command -v python3 >/dev/null 2>&1 || { echo "❌ python3 nicht gefunden"; exit 1; }
command -v npm     >/dev/null 2>&1 || { echo "❌ npm nicht gefunden"; exit 1; }

if [ ! -f "$ROOT/backend/.env" ]; then
  echo "⚠  Keine .env-Datei gefunden. Kopiere .env.example nach .env ..."
  cp "$ROOT/backend/.env.example" "$ROOT/backend/.env"
  echo "   → Bitte ANTHROPIC_API_KEY in backend/.env eintragen."
fi

# ── Backend ────────────────────────────────────────────────────────────────
echo "▶ Starte Backend auf http://localhost:8000 ..."
cd "$ROOT/backend"
python3 -m uvicorn main:app --reload --port 8000 &
BACKEND_PID=$!

# ── Frontend ───────────────────────────────────────────────────────────────
echo "▶ Starte Frontend auf http://localhost:5173 ..."
cd "$ROOT/frontend"
npm run dev &
FRONTEND_PID=$!

echo ""
echo "✅  GAIO Analyzer läuft:"
echo "   Frontend: http://localhost:5173"
echo "   Backend:  http://localhost:8000"
echo "   API-Docs: http://localhost:8000/docs"
echo ""
echo "   Beenden mit Ctrl+C"

# ── Cleanup ────────────────────────────────────────────────────────────────
trap "echo ''; echo 'Stoppe Services...'; kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; exit 0" INT TERM
wait
