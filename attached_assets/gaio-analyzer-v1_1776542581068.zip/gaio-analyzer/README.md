# GAIO Analyzer

B2B-Website-Audit-Tool für LLM-Sichtbarkeit und klassische SEO.

## Voraussetzungen

- Python 3.10+
- Node.js 18+
- Anthropic API Key

---

## Setup & Start

### 1. Backend

```bash
cd backend
pip install -r requirements.txt

# API Key konfigurieren
cp .env.example .env
# ANTHROPIC_API_KEY in .env eintragen

# Server starten
uvicorn main:app --reload --port 8000
```

### 2. Frontend (Entwicklung)

```bash
cd frontend
npm install
npm run dev
# → http://localhost:5173
```

### Produktiv-Deployment

```bash
cd frontend
npm run build
# dist/ Ordner auf beliebigen Static-Host deployen
# Oder: FastAPI serviert dist/ direkt (erweitere main.py mit StaticFiles-Mount)
```

---

## Projektstruktur

```
gaio-analyzer/
├── backend/
│   ├── main.py              # FastAPI App + alle API-Endpunkte
│   ├── requirements.txt
│   ├── .env.example
│   └── modules/
│       ├── crawler.py       # Website-Crawling (async httpx)
│       ├── technical_seo.py # Technische SEO-Analyse
│       ├── schema_analysis.py # Schema.org / extruct
│       ├── heading_analysis.py # H1/H2/H3 Analyse
│       ├── llm_analysis.py  # Content + FAQ + LLM-Simulation (Anthropic)
│       ├── competitor.py    # Wettbewerbs-Analyse
│       └── scoring.py       # Score-Berechnung + Empfehlungen
└── frontend/
    └── src/
        ├── App.tsx
        ├── store/appStore.ts   # Zustand (persistiert in localStorage)
        ├── types/index.ts
        ├── components/Sidebar.tsx
        └── views/
            ├── DomainAnalysis.tsx
            ├── HtmlAnalysis.tsx
            ├── Results.tsx       # Alle Charts + Module
            ├── FAQView.tsx       # Dokumentation / How-it-works
            └── Settings.tsx
```

---

## API-Endpunkte

| Methode | Pfad | Beschreibung |
|---------|------|--------------|
| POST | /api/analyze/domain | Domain-Analyse starten |
| POST | /api/analyze/html   | HTML-Analyse starten |
| GET  | /api/analysis/{id}/stream | SSE-Stream (Live-Fortschritt) |
| GET  | /api/analysis/{id}/results | Finale Ergebnisse |
| GET  | /api/health | Server-Status + API-Key-Check |

---

## Analyse-Module & Score-Gewichtung

| Modul | Gewicht |
|-------|---------|
| Strukturierte Daten (Schema.org) | 20% |
| Inhaltliche Relevanz (KI) | 20% |
| LLM-Sichtbarkeits-Simulation | 20% |
| Technische SEO-Basis | 15% |
| FAQ-Qualität | 15% |
| Heading-Struktur | 10% |

---

## Hinweise

- **Ohne Anthropic API Key**: Technische Module (SEO, Schema, Headings) laufen ohne Key.
  KI-gestützte Module (Content, FAQ-Qualität, LLM-Simulation, Empfehlungen) benötigen den Key.
- **Robots.txt**: Der Crawler respektiert robots.txt-Einträge.
- **Wettbewerber**: Werden mit einer einzelnen Seite (Startseite) analysiert — kein Vollcrawl.
- **In-Memory-Storage**: Task-Ergebnisse werden nur im RAM gehalten (kein Redis/DB). 
  Bei Neustart des Servers gehen laufende Tasks verloren.
